THEMES SELLER PAY - ANDROID APP (SMS -> ওয়েবসাইট অটো পেমেন্ট)
================================================================

এই অ্যাপ কী করে
- ফোনে bKash/Nagad/Rocket-এর "টাকা পেয়েছেন" SMS এলে সেটা নিজে নিজে আপনার সাইটে (themesseller.com.bd) পাঠিয়ে দেয়।
- কাস্টমার TrxID দিলে সাইট সাথে সাথে অর্ডার কনফার্ম করে। আপনাকে কিছু করতে হয় না।
- শুধু পেমেন্টের SMS পাঠায়। অন্য কোনো SMS ফোন থেকে বের হয় না।

APK বানানো (একবারই লাগবে, প্রায় ৫-১০ মিনিট)
1) github.com-এ বিনামূল্যে একাউন্ট খুলুন। New repository বানান (Private রাখুন)।
2) এই ZIP-এর সব ফাইল ও ফোল্ডার ওই repository-তে আপলোড করুন (Add file -> Upload files)।
   যদি ".github" ফোল্ডার আপলোড না হয়: Add file -> Create new file -> নাম লিখুন
   .github/workflows/build-apk.yml  এবং এই ZIP-এর ভেতরের একই নামের ফাইলের লেখা পেস্ট করুন।
3) Actions ট্যাব -> "Build APK" -> Run workflow চাপুন।
4) সবুজ টিক এলে ওই রানে ঢুকে নিচে "ThemesSellerPay-APK" ডাউনলোড করুন। ZIP খুললে ThemesSellerPay.apk পাবেন।
5) Build ফেল করলে লগের লেখাটা আমাকে পাঠান, আমি ঠিক করে দেব।

ফোনে চালু করা
1) ThemesSellerPay.apk ফোনে ইনস্টল করুন (Unknown sources / এই সোর্স থেকে ইনস্টল অনুমতি দিন)।
2) ওয়েবসাইটের অ্যাডমিনে WooCommerce -> Themes Seller Pay -> "Create pairing code for the phone app" চাপুন।
3) অ্যাপ খুলে ৬ ডিজিটের কোড লিখে "সংযুক্ত করুন" চাপুন। SMS অনুমতি দিন।
4) "ব্যাটারি সেভার বন্ধ করুন" চাপুন (না করলে ফোন ঘুমিয়ে গেলে SMS দেরিতে যেতে পারে)।
5) "সংযোগ পরীক্ষা করুন" চাপুন। "সংযোগ ঠিক আছে" এলে কাজ শেষ।

Android 13+ ফোনে SMS অনুমতির অপশন না এলে: Settings -> Apps -> Themes Seller Pay -> উপরে ডানের ⋮ -> "Allow restricted settings"।

নিরাপত্তা
- ডিভাইস কী APK-তে লেখা নেই; পেয়ারিংয়ের সময় সাইট থেকে আসে। তাই APK অন্যের হাতে গেলেও সাইট নিরাপদ।
- repository অবশ্যই Private রাখুন (সাইনিং কী ভেতরে আছে)।
- সাইটের ডোমেইন বদলালে app/build.gradle.kts-এ SERVER_URL বদলে আবার বিল্ড করুন।
