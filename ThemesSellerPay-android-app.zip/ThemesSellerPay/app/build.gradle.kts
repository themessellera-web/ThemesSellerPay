plugins {
    id("com.android.application")
}

android {
    namespace = "bd.com.themesseller.pay"
    compileSdk = 34

    defaultConfig {
        applicationId = "bd.com.themesseller.pay"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // The site the app talks to. Change here only if your domain changes.
        buildConfigField("String", "SERVER_URL", "\"https://themesseller.com.bd\"")
    }

    buildFeatures {
        buildConfig = true
    }

    // Fixed signing key so a newer APK can be installed over the older one (the phone stays connected).
    signingConfigs {
        create("release") {
            storeFile = file("../keystore/themesseller-pay.jks")
            storePassword = "themesseller-pay-2026"
            keyAlias = "themessellerpay"
            keyPassword = "themesseller-pay-2026"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.work:work-runtime:2.9.1")
}
