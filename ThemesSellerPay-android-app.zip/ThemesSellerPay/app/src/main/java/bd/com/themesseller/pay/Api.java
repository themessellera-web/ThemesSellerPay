package bd.com.themesseller.pay;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Calls the Themes Seller Pay API of the website (no extra libraries). */
final class Api {
    private Api() {
    }

    static final class Res {
        int code = 0;
        JSONObject json = null;
        String error = null;
    }

    private static String base() {
        String b = BuildConfig.SERVER_URL;
        while (b.endsWith("/")) {
            b = b.substring(0, b.length() - 1);
        }
        return b + "/wp-json/ts-pay/v1";
    }

    /** Trade the 6-digit code shown in the admin panel for the device key. */
    static Res pair(String code) {
        try {
            JSONObject b = new JSONObject();
            b.put("code", code);
            return call("POST", "/devices/pair", null, b);
        } catch (Exception e) {
            Res r = new Res();
            r.error = String.valueOf(e.getMessage());
            return r;
        }
    }

    /** Send received SMS (body = {"messages":[...]}). */
    static Res post(String path, String key, JSONObject body) {
        return call("POST", path, key, body);
    }

    /** Connection test / heartbeat. */
    static Res get(String path, String key) {
        return call("GET", path, key, null);
    }

    private static Res call(String method, String path, String key, JSONObject body) {
        Res r = new Res();
        HttpURLConnection c = null;
        try {
            URL u = new URL(base() + path);
            c = (HttpURLConnection) u.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setRequestMethod(method);
            c.setConnectTimeout(20000);
            c.setReadTimeout(25000);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "ThemesSellerPay-Android/" + BuildConfig.VERSION_NAME);
            if (key != null && key.length() > 0) {
                c.setRequestProperty("x-ts-secret", key);
            }
            if (body != null) {
                byte[] bytes = body.toString().getBytes("UTF-8");
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                c.setFixedLengthStreamingMode(bytes.length);
                OutputStream os = c.getOutputStream();
                os.write(bytes);
                os.close();
            }
            r.code = c.getResponseCode();
            if (r.code >= 300 && r.code < 400) {
                r.error = "Server redirect (" + r.code + ") to " + c.getHeaderField("Location");
                return r;
            }
            InputStream is = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = read(is);
            try {
                r.json = new JSONObject(text);
            } catch (Exception ignored) {
                if (r.code >= 400) {
                    r.error = "HTTP " + r.code;
                }
            }
        } catch (Exception e) {
            r.error = e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            if (c != null) {
                c.disconnect();
            }
        }
        return r;
    }

    private static String read(InputStream is) throws Exception {
        if (is == null) {
            return "";
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = is.read(buf)) > 0) {
            out.write(buf, 0, n);
        }
        is.close();
        return out.toString("UTF-8");
    }
}
