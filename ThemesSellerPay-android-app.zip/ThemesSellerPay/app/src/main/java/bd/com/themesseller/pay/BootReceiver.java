package bd.com.themesseller.pay;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** After a phone restart or an app update: start the background sync again. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Store.isPaired(context)) {
            return;
        }
        Sync.schedulePeriodic(context);
        Sync.kick(context);
    }
}
