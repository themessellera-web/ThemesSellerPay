package bd.com.themesseller.pay;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** One simple screen: connect with the 6-digit code, allow SMS, done. */
public class MainActivity extends Activity {
    private static final int C_BLUE = Color.parseColor("#1D3F9B");
    private static final int C_RED = Color.parseColor("#D7263D");
    private static final int C_GREEN = Color.parseColor("#12805C");
    private static final int C_GRAY = Color.parseColor("#5B6475");
    private static final int C_DARK = Color.parseColor("#1B2333");

    private TextView statusView;
    private TextView permView;
    private TextView statsView;
    private TextView errView;
    private TextView pairMsg;
    private EditText codeInput;
    private Button connectBtn;
    private Button permBtn;
    private Button batteryBtn;
    private Button testBtn;
    private Button unpairBtn;
    private LinearLayout pairBox;
    private LinearLayout pairedBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        if (Store.isPaired(this)) {
            Sync.schedulePeriodic(this);
            if (Store.pending(this) > 0) {
                Sync.kick(this);
            }
        }
    }

    /* ------------------------------------------------------------ UI */

    private View buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(Color.parseColor("#F4F6FB"));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(20), dp(36), dp(20), dp(28));
        sv.addView(root);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        root.addView(logo, new LinearLayout.LayoutParams(dp(84), dp(84)));

        TextView title = text("Themes Seller Pay", 22, C_DARK, true);
        title.setGravity(Gravity.CENTER);
        add(root, title, 10);

        TextView sub = text("অটোমেটিক পেমেন্ট ভেরিফিকেশন অ্যাপ", 14, C_GRAY, false);
        sub.setGravity(Gravity.CENTER);
        add(root, sub, 2);

        statusView = text("", 15, Color.WHITE, true);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(16), dp(12), dp(16), dp(12));
        add(root, statusView, 22);

        /* --- before connecting --- */
        pairBox = new LinearLayout(this);
        pairBox.setOrientation(LinearLayout.VERTICAL);
        add(root, pairBox, 18);

        TextView how = text("ওয়েবসাইটের অ্যাডমিন প্যানেলে WooCommerce → Themes Seller Pay খুলে \"Create pairing code\" বাটন চাপুন। তারপর যে ৬ ডিজিটের কোড আসবে সেটা নিচে লিখুন।", 14, C_GRAY, false);
        add(pairBox, how, 0);

        codeInput = new EditText(this);
        codeInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        codeInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(6)});
        codeInput.setHint("000000");
        codeInput.setTextSize(28);
        codeInput.setGravity(Gravity.CENTER);
        codeInput.setLetterSpacing(0.3f);
        codeInput.setTextColor(C_DARK);
        codeInput.setBackground(rounded(Color.WHITE, 12));
        codeInput.setPadding(dp(12), dp(14), dp(12), dp(14));
        add(pairBox, codeInput, 14);

        connectBtn = button("সংযুক্ত করুন", C_BLUE, Color.WHITE);
        connectBtn.setOnClickListener(v -> doPair());
        add(pairBox, connectBtn, 12);

        pairMsg = text("", 13, C_RED, false);
        pairMsg.setGravity(Gravity.CENTER);
        add(pairBox, pairMsg, 8);

        /* --- after connecting --- */
        pairedBox = new LinearLayout(this);
        pairedBox.setOrientation(LinearLayout.VERTICAL);
        add(root, pairedBox, 18);

        permView = text("", 14, C_DARK, true);
        add(pairedBox, permView, 0);

        permBtn = button("SMS অনুমতি দিন", C_BLUE, Color.WHITE);
        permBtn.setOnClickListener(v -> askSmsPermission());
        add(pairedBox, permBtn, 8);

        batteryBtn = button("ব্যাটারি সেভার বন্ধ করুন (জরুরি)", Color.parseColor("#E8EDF9"), C_BLUE);
        batteryBtn.setOnClickListener(v -> askBattery());
        add(pairedBox, batteryBtn, 10);

        statsView = text("", 14, C_DARK, false);
        statsView.setBackground(rounded(Color.WHITE, 12));
        statsView.setPadding(dp(14), dp(12), dp(14), dp(12));
        add(pairedBox, statsView, 14);

        errView = text("", 13, C_RED, false);
        add(pairedBox, errView, 8);

        testBtn = button("সংযোগ পরীক্ষা করুন", Color.parseColor("#E8EDF9"), C_BLUE);
        testBtn.setOnClickListener(v -> testConnection());
        add(pairedBox, testBtn, 14);

        unpairBtn = button("ডিসকানেক্ট", Color.parseColor("#FBE9EC"), C_RED);
        unpairBtn.setOnClickListener(v -> confirmUnpair());
        add(pairedBox, unpairBtn, 10);

        TextView hint = text("SMS অনুমতির অপশন না এলে: ফোনের Settings → Apps → Themes Seller Pay → উপরে ডানের ⋮ → \"Allow restricted settings\" চালু করে আবার চেষ্টা করুন।", 12, C_GRAY, false);
        add(root, hint, 24);

        TextView ver = text("Version " + BuildConfig.VERSION_NAME + "  •  " + BuildConfig.SERVER_URL.replace("https://", ""), 11, C_GRAY, false);
        ver.setGravity(Gravity.CENTER);
        add(root, ver, 14);

        return sv;
    }

    private void refresh() {
        boolean paired = Store.isPaired(this);
        boolean perm = checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED;

        pairBox.setVisibility(paired ? View.GONE : View.VISIBLE);
        pairedBox.setVisibility(paired ? View.VISIBLE : View.GONE);

        String status;
        int color;
        if (!paired) {
            status = "● সংযুক্ত নয়";
            color = C_RED;
        } else if (Store.badKey(this)) {
            status = "● সংযোগের কী বাতিল হয়েছে — ডিসকানেক্ট করে আবার কানেক্ট করুন";
            color = C_RED;
        } else if (!perm) {
            status = "● SMS অনুমতি বাকি";
            color = C_RED;
        } else {
            status = "● চালু আছে — পেমেন্ট SMS অটো সাইটে যাবে";
            color = C_GREEN;
        }
        statusView.setText(status);
        statusView.setBackground(rounded(color, 14));

        permView.setText(perm ? "SMS অনুমতি: দেওয়া আছে ✓" : "SMS অনুমতি: দেওয়া হয়নি");
        permBtn.setVisibility(perm ? View.GONE : View.VISIBLE);

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean ignoring = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        batteryBtn.setVisibility(ignoring ? View.GONE : View.VISIBLE);

        long last = Store.lastOk(this);
        String lastText = last > 0 ? new SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(new Date(last)) : "এখনো হয়নি";
        statsView.setText("অপেক্ষায় আছে: " + Store.pending(this) + " টি\n"
                + "সাইটে পাঠানো হয়েছে: " + Store.synced(this) + " টি\n"
                + "অটো কনফার্ম হয়েছে: " + Store.matched(this) + " টি\n"
                + "শেষ সফল সংযোগ: " + lastText);

        String err = Store.lastErr(this);
        errView.setText(err.length() > 0 ? "সমস্যা: " + err : "");
        errView.setVisibility(err.length() > 0 ? View.VISIBLE : View.GONE);
    }

    /* ------------------------------------------------------------ actions */

    private void doPair() {
        final String code = codeInput.getText().toString().replaceAll("\\D", "");
        if (code.length() != 6) {
            pairMsg.setText("৬ ডিজিটের কোড লিখুন");
            return;
        }
        pairMsg.setText("");
        connectBtn.setEnabled(false);
        connectBtn.setText("সংযোগ হচ্ছে...");
        new Thread(() -> {
            final Api.Res r = Api.pair(code);
            runOnUiThread(() -> {
                connectBtn.setEnabled(true);
                connectBtn.setText("সংযুক্ত করুন");
                String key = r.json != null ? r.json.optString("key", "") : "";
                if (r.code == 200 && r.json != null && r.json.optBoolean("ok", false) && key.length() > 0) {
                    Store.savePair(this, key, r.json.optString("name", ""));
                    codeInput.setText("");
                    Sync.schedulePeriodic(this);
                    Sync.kick(this);
                    refresh();
                    if (checkSelfPermission(Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
                        askSmsPermission();
                    }
                } else {
                    String msg;
                    if (r.json != null && r.json.optString("message", "").length() > 0) {
                        msg = r.json.optString("message");
                    } else if (r.error != null) {
                        msg = r.error;
                    } else {
                        msg = "HTTP " + r.code;
                    }
                    pairMsg.setText("সংযোগ হয়নি: " + msg);
                }
            });
        }).start();
    }

    private void askSmsPermission() {
        requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS}, 1);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refresh();
    }

    private void askBattery() {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignored) {
                Toast.makeText(this, "Settings → Battery থেকে এই অ্যাপের ব্যাটারি সেভার বন্ধ করুন", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void testConnection() {
        final String key = Store.getKey(this);
        testBtn.setEnabled(false);
        new Thread(() -> {
            final Api.Res r = Api.get("/devices/sync", key);
            runOnUiThread(() -> {
                testBtn.setEnabled(true);
                String msg;
                if (r.code == 403) {
                    Store.setBadKey(this);
                    msg = "কী মেলেনি — ডিসকানেক্ট করে আবার কানেক্ট করুন";
                } else if (r.code >= 200 && r.code < 300) {
                    Store.touchOk(this);
                    msg = "সংযোগ ঠিক আছে ✓";
                    if (Store.pending(this) > 0) {
                        Sync.kick(this);
                    }
                } else {
                    msg = "সংযোগ হয়নি: " + (r.error != null ? r.error : "HTTP " + r.code);
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
                refresh();
            });
        }).start();
    }

    private void confirmUnpair() {
        new AlertDialog.Builder(this)
                .setTitle("ডিসকানেক্ট করবেন?")
                .setMessage("ডিসকানেক্ট করলে এই ফোন থেকে আর SMS সাইটে যাবে না। আবার কানেক্ট করতে নতুন কোড লাগবে।")
                .setPositiveButton("হ্যাঁ, ডিসকানেক্ট", (d, w) -> {
                    Sync.cancelAll(this);
                    Store.unpair(this);
                    refresh();
                })
                .setNegativeButton("না", null)
                .show();
    }

    /* ------------------------------------------------------------ view helpers */

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private Button button(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(rounded(bg, 12));
        b.setPadding(dp(12), dp(14), dp(12), dp(14));
        return b;
    }

    private void add(LinearLayout parent, View v, int topMarginDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(topMarginDp);
        parent.addView(v, lp);
    }
}
