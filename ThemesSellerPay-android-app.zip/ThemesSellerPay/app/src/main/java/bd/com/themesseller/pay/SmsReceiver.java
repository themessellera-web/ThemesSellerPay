package bd.com.themesseller.pay;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import java.util.regex.Pattern;

/** Gets every incoming SMS. Only money-received messages are kept and sent to the website. */
public class SmsReceiver extends BroadcastReceiver {
    private static final Pattern RECEIVED = Pattern.compile("(?i)(received|credited|cash\\s?in)");
    private static final Pattern TRX = Pattern.compile("(?i)(trx|txn|tran)");

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !"android.provider.Telephony.SMS_RECEIVED".equals(intent.getAction())) {
            return;
        }
        if (!Store.isPaired(context)) {
            return;
        }
        SmsMessage[] parts = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (parts == null || parts.length == 0) {
            return;
        }
        String from = parts[0] != null ? parts[0].getOriginatingAddress() : "";
        StringBuilder sb = new StringBuilder();
        for (SmsMessage m : parts) {
            if (m != null && m.getMessageBody() != null) {
                sb.append(m.getMessageBody());
            }
        }
        String body = sb.toString();
        if (!RECEIVED.matcher(body).find() || !TRX.matcher(body).find()) {
            return; // not a payment SMS: ignore, never leaves the phone
        }
        Store.enqueue(context, from == null ? "" : from, body);
        Sync.kick(context);
    }
}
