package bd.com.themesseller.pay;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Set;
import java.util.UUID;

/** Tiny local storage: device key, the list of SMS waiting to be sent, and a few counters. */
final class Store {
    private static final String FILE = "ts_pay";
    private static final int MAX_QUEUE = 200;

    private Store() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /* ---------- pairing ---------- */

    static boolean isPaired(Context c) {
        return getKey(c).length() > 0;
    }

    static String getKey(Context c) {
        return sp(c).getString("key", "");
    }

    static String getName(Context c) {
        return sp(c).getString("name", "");
    }

    static void savePair(Context c, String key, String name) {
        sp(c).edit()
                .putString("key", key)
                .putString("name", name)
                .putBoolean("bad_key", false)
                .putString("last_err", "")
                .apply();
    }

    static void unpair(Context c) {
        sp(c).edit().clear().apply();
    }

    /* ---------- queue ---------- */

    static synchronized void enqueue(Context c, String from, String message) {
        try {
            JSONArray q = new JSONArray(sp(c).getString("queue", "[]"));
            JSONObject m = new JSONObject();
            m.put("id", UUID.randomUUID().toString());
            m.put("from", from);
            m.put("message", message);
            m.put("time", System.currentTimeMillis() / 1000L);
            q.put(m);
            JSONArray out = q;
            if (q.length() > MAX_QUEUE) {
                out = new JSONArray();
                for (int i = q.length() - MAX_QUEUE; i < q.length(); i++) {
                    out.put(q.get(i));
                }
            }
            sp(c).edit().putString("queue", out.toString()).apply();
        } catch (Exception ignored) {
            // never crash the SMS receiver
        }
    }

    static synchronized JSONArray peek(Context c, int max) {
        JSONArray out = new JSONArray();
        try {
            JSONArray q = new JSONArray(sp(c).getString("queue", "[]"));
            for (int i = 0; i < q.length() && i < max; i++) {
                out.put(q.get(i));
            }
        } catch (Exception ignored) {
            // empty
        }
        return out;
    }

    static synchronized void remove(Context c, Set<String> ids) {
        try {
            JSONArray q = new JSONArray(sp(c).getString("queue", "[]"));
            JSONArray keep = new JSONArray();
            for (int i = 0; i < q.length(); i++) {
                JSONObject m = q.getJSONObject(i);
                if (!ids.contains(m.optString("id"))) {
                    keep.put(m);
                }
            }
            sp(c).edit().putString("queue", keep.toString()).apply();
        } catch (Exception ignored) {
            // leave the queue as it is
        }
    }

    static synchronized int pending(Context c) {
        try {
            return new JSONArray(sp(c).getString("queue", "[]")).length();
        } catch (Exception e) {
            return 0;
        }
    }

    /* ---------- counters / status ---------- */

    static synchronized void addSynced(Context c, int sent, int matched) {
        SharedPreferences p = sp(c);
        p.edit()
                .putInt("synced", p.getInt("synced", 0) + sent)
                .putInt("matched", p.getInt("matched", 0) + matched)
                .putLong("last_ok", System.currentTimeMillis())
                .putString("last_err", "")
                .putBoolean("bad_key", false)
                .apply();
    }

    static void touchOk(Context c) {
        sp(c).edit()
                .putLong("last_ok", System.currentTimeMillis())
                .putString("last_err", "")
                .putBoolean("bad_key", false)
                .apply();
    }

    static void setError(Context c, String err) {
        sp(c).edit().putString("last_err", err == null ? "" : err).apply();
    }

    static void setBadKey(Context c) {
        sp(c).edit().putBoolean("bad_key", true).putString("last_err", "").apply();
    }

    static int synced(Context c) {
        return sp(c).getInt("synced", 0);
    }

    static int matched(Context c) {
        return sp(c).getInt("matched", 0);
    }

    static long lastOk(Context c) {
        return sp(c).getLong("last_ok", 0L);
    }

    static String lastErr(Context c) {
        return sp(c).getString("last_err", "");
    }

    static boolean badKey(Context c) {
        return sp(c).getBoolean("bad_key", false);
    }
}
