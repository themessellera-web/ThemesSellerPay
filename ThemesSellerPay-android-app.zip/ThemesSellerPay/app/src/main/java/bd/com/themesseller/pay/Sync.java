package bd.com.themesseller.pay;

import android.content.Context;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

/** Schedules the background upload. Works even when the app screen is closed. */
final class Sync {
    private Sync() {
    }

    private static Constraints online() {
        return new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
    }

    /** Upload right now (as soon as there is internet). */
    static void kick(Context c) {
        OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(SyncWorker.class)
                .setConstraints(online())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(c.getApplicationContext())
                .enqueueUniqueWork("ts-sync", ExistingWorkPolicy.REPLACE, req);
    }

    /** Every 15 minutes: send anything left over and tell the site the phone is alive. */
    static void schedulePeriodic(Context c) {
        PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(SyncWorker.class, 15, TimeUnit.MINUTES)
                .setConstraints(online())
                .build();
        WorkManager.getInstance(c.getApplicationContext())
                .enqueueUniquePeriodicWork("ts-sync-periodic", ExistingPeriodicWorkPolicy.KEEP, req);
    }

    static void cancelAll(Context c) {
        WorkManager.getInstance(c.getApplicationContext()).cancelAllWork();
    }
}
