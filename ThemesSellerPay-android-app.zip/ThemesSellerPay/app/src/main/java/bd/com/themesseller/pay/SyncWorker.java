package bd.com.themesseller.pay;

import android.content.Context;

import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashSet;
import java.util.Set;

/** Sends the queued SMS to the website; removes them from the queue only after the site confirmed. */
public class SyncWorker extends Worker {

    public SyncWorker(Context context, WorkerParameters params) {
        super(context, params);
    }

    @Override
    public Result doWork() {
        Context c = getApplicationContext();
        String key = Store.getKey(c);
        if (key.length() == 0) {
            return Result.success();
        }

        boolean sentAny = false;
        try {
            for (int round = 0; round < 10; round++) {
                JSONArray batch = Store.peek(c, 50);
                if (batch.length() == 0) {
                    break;
                }
                JSONObject body = new JSONObject();
                body.put("messages", batch);
                Api.Res r = Api.post("/devices/sync", key, body);

                if (r.code == 403) {
                    Store.setBadKey(c);
                    return Result.success();
                }
                boolean ok = r.code >= 200 && r.code < 300 && r.json != null && r.json.optBoolean("ok", false);
                if (!ok) {
                    Store.setError(c, r.error != null ? r.error : "HTTP " + r.code);
                    // network problem or server error: try again later; other errors wait for the next periodic run
                    return (r.error != null || r.code == 0 || r.code >= 500 || r.code == 429) ? Result.retry() : Result.success();
                }

                Set<String> ids = new HashSet<>();
                for (int i = 0; i < batch.length(); i++) {
                    ids.add(batch.getJSONObject(i).optString("id"));
                }
                Store.remove(c, ids);
                Store.addSynced(c, batch.length(), r.json.optInt("matched", 0));
                sentAny = true;
            }

            if (!sentAny) {
                // nothing to send: heartbeat so the website can show "phone last seen"
                Api.Res ping = Api.get("/devices/sync", key);
                if (ping.code == 403) {
                    Store.setBadKey(c);
                } else if (ping.code >= 200 && ping.code < 300) {
                    Store.touchOk(c);
                } else {
                    Store.setError(c, ping.error != null ? ping.error : "HTTP " + ping.code);
                }
            }
            return Result.success();
        } catch (Exception e) {
            Store.setError(c, String.valueOf(e.getMessage()));
            return Result.retry();
        }
    }
}
